# ZeroTwoChk Safe Bot

Bot de Telegram con `/start` y `/gen`, inspirado en el formato de la captura,
pero diseñado exclusivamente para datos ficticios de prueba.

## 1. Crear el bot

En Telegram abre `@BotFather`, usa `/newbot` y elige un nombre y un
@username disponibles. Copia el token que te entregue BotFather.

## 2. Instalar

```bash
python -m pip install -r requirements.txt
```

## 3. Configurar el token

Linux/macOS:
```bash
export BOT_TOKEN="TU_TOKEN_AQUI"
```

Windows PowerShell:
```powershell
$env:BOT_TOKEN="TU_TOKEN_AQUI"
```

## 4. Ejecutar

```bash
python bot.py
```

## Comandos

`/start`

`/gen DEMO-123`

El bot rechaza entradas que parezcan números de tarjetas de pago y solo
genera identificadores de prueba, fechas ficticias y valores `XXX`.
